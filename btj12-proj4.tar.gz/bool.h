/*
Brett Johnson
btj12
bool.h
2/27/2017
This file holds a struct that is boolean
*/
#ifndef bool_header_file
#define bool_header_file

typedef enum boolean bool;
enum boolean{
   true = 1,
   false = 0,
};


#endif
